const mongoose = require('mongoose');
const plm = require('passport-local-mongoose')

const Schema = mongoose.Schema;

const User = new Schema({
  Id: String,
  Name: String
});

User.plugin(plm);

module.exports = mongoose.model('User', User);