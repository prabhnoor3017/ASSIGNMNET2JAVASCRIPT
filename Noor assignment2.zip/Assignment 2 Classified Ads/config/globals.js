module.exports =
    {
    'db': 'mongodb+srv://prabhnoor:prabhnoor@cluster0.t8yzr.mongodb.net/Advertisements?retryWrites=true&w=majority',
        ids: {
        'google': {
            clientID: '77827465527-7ijqthvk0uf8tqsjod9udpt7d1j7s6od.apps.googleusercontent.com',
            clientSecret: '_sUon7bOov13_2cC_jcvCIeQ',
            callbackURL: 'http://localhost:3000/google/callback'
        },
        }
}