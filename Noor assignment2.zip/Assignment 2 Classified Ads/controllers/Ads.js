var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var Ad = require('../models/Ad');
const passport = require('passport')
const User = require('../models/User')

router.get("/", async (req, res) => {
	Ad.find((err, adds) => {
        if (err) {
            console.log(err)
            res.end(err)
        }
        else {
            res.render('index',
                {
                    ads: adds,
                    user: req.user
                })
        }
    })
 })
 
function isLoggedIn(req,res, next){
    if(req.isAuthenticated()){
        return next()
    }
    res.redirect('/')
}

router.get('/add', isLoggedIn,(req, res, next) => {
    res.render('ads/add', {
        user: req.user
        })
})

router.get('/edit/:_id', isLoggedIn,(req, res, next) => {
	
	   Ad.findById(req.params._id,(err,add) => {
        if(err)
        {
            console.log(err)
            res.end(err)
        }
        else
        {
            res.render('ads/edit',
                { ads: add,
                user: req.user
				})
        }
})
})
router.post('/edit/:_id', isLoggedIn,(req, res, next) => {
	
	var add = req.body
	Ad.update({_id: req.params._id}, add,(err) => {
        if(err)
        {
            console.log(err)
            res.end(err)
        }
        else
        {
            res.redirect('/')
        }
})
})

router.get('/view/:_id', isLoggedIn,(req, res, next) => {
	
	   Ad.findById(req.params._id,(err,add) => {
        if(err)
        {
            console.log(err)
            res.end(err)
        }
        else
        {
            res.render('ads/view',
                { 
				ads: add,
                user: req.user
				})
        }
})
})

router.get('/delete/:_id', isLoggedIn,(req, res, next) => {
	
	   Ad.remove({_id: req.params._id},(err,add) => {
        if(err)
        {
            console.log(err)
            res.end(err)
        }
        else
        {
			res.redirect('/')
        }
})
})

router.post('/add', isLoggedIn,(req, res, next) =>
{
    Ad.create({
        Title: req.body.Title,
        Description: req.body.Description,
        Price: req.body.Price
    }, (err, ad) => {
        if(err)
        {
            console.log(err)
            res.end(err)
        }
        else
        {
            res.redirect('/')
        }
    })
})

router.get('/json', (req,res,next) => {
	Ad.find((err, adds) => {
        if (err) {
            console.log(err)
            res.end(err)
        }
        else {
			
	res.send({
      adds
    });
        }
    })
})

router.get('/google', passport.authenticate('google', { scope: ['profile', 'email'] }), (req, res) => {})

router.get('/google/callback', passport.authenticate('google'),
    (req,res) =>{
  res.redirect('/')
})



router.get('/logout', (req, res) => {
  req.logout();
  res.redirect('/');
});



module.exports = router;